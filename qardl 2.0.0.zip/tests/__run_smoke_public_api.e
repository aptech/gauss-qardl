new;
chdir "C:/Users/eclow/Documents/GitHub/gauss-qardl/tests";
run smoke_public_api.e;
